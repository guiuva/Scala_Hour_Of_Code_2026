object ProyectoAlumnos {

  case class Alumno(nombre: String,
                     nota: Double,
                     curso: String)

  def main(args: Array[String]): Unit = {

    val alumnos = List(
      Alumno("Ana", 8.5, "Scala"),
      Alumno("Luis", 4.2, "Scala"),
      Alumno("María", 9.1, "Spark"),
      Alumno("Pedro", 5.5, "Spark"),
      Alumno("Carlos", 3.8, "Scala"),
      Alumno("Laura", 8.7, "Spark")
    )

    // Ejercicio 1, Obtener los alumnos que hayan aprobado

    // Ejercicio 2, Obtener los nombres de los alumnos

    // Ejercicio 3, ¿Laura está aprobada? ¿Y John?

    // Ejercicio 4, ¿Cual es el alumno con mejor nota?

    // Ejercicio 5, ¿Cual es el ranking de mejor a peor alumno por nota? ¿Y del peor al mejor?

    // Ejercicio 6, ¿Cuantos alumnos hay en cada curso? ¿Quienes son?

    // Ejercicio 7, Haz una función para clasificar a los alumnos en función de su nota y utilizala
    // >= 9 Sobresaliente, >=7 Notable, >= 5 Aprobado, en cualquier otro caso suspenso

    // Ejercicio 8, Obten los nombres (solo nombres) de los alumnos aprobados del curso de Spark ordenados por nota

    // Extra 1, ¿Hay algún suspenso?

    // Extra 2, ¿Están todos aprobados?

    // Extra 3, ¿Cual es la nota media de la clase?

    // Extra 4, Haz una tupla con los alumnos suspensos a la izquierda y los aprobados a la derecha. ¿Y un Map?




  }

}
