object Ejercicio1 {

  def main(args: Array[String]): Unit = {

    val numeros = List(1, 2, 3, 4, 5)

    //map. Transformar los datos
    val duplicados = numeros.map(_ * 2)
    //println(duplicados)

    //filter. filtra los datos en base a una condición
    val pares = numeros.filter(_ % 2 == 0)
    //println(pares)

    //Varias a la vez
    val resultado = numeros
      .filter(_ % 2 == 0)
      .map(_ * 10)
    //println(resultado)

  }

}
