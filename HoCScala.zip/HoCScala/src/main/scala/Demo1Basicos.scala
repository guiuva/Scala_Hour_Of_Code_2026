object Demo1Basicos {

  /**
   * Demostración sobre como llamar funciones
   * @param x Número del que calcular el cuadrado
   * @return El cuadrado del número
   */
  def cuadrado(x: Int): Int = {
    x * x
  }

  def main(args: Array[String]): Unit = {

    val nombre = "Manuel"
    val edad = 35
    val esMayor = true

    //Inmutabilidad con listas
    val numeros = List(1, 2, 3)
    val nuevosNumeros = numeros :+ 4
    println(numeros)
    println(nuevosNumeros)

    //Uso de funciones
    //println(cuadrado(5))

    /** Asignar funciones a variables
     * val cuadrado = (x: Int) => x * x
     */


    //For comprehension
    val resultado =
      for {
        n <- numeros
        if n % 2 == 0
      } yield n * 10

    numeros
      .filter(_ % 2 == 0)
      .map(_ * 10)

  }


}
