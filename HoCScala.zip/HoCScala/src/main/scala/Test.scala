import org.apache.spark.sql.SparkSession

object Test {

  def main(args: Array[String]): Unit = {

    val spark = SparkSession.builder()
      .appName("Test")
      .master("local[*]")
      .getOrCreate()


    println("Hello world!")

    //println(s"Version de spark: ${spark.version}")

    val datos = Seq(("Ana", 28), ("Carlos", 30), ("Elena", 12))

    import spark.implicits._

    val df = datos.toDF("Nombre", "Edad")
    df.show
  }

}
