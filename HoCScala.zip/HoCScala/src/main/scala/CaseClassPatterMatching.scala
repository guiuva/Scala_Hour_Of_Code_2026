object CaseClassPatterMatching {

  def evaluarNota(nota: Int) =
    nota match {
      case n if n >= 9 => "Sobresaliente"
      case n if n >= 7 => "Notable"
      case n if n >= 5 => "Aprobado"
      case _           => "Suspenso"
    }

  case class Alumno(nombre: String,
                     nota: Double)

  def main(args: Array[String]): Unit = {

    val alumnos = List(
      Alumno("Ana", 8.5),
      Alumno("Luis", 4.2),
      Alumno("Maria", 9.1)
    )

    val aprobados =
      alumnos.filter(_.nota >= 5)

    println(aprobados)


  }

}
